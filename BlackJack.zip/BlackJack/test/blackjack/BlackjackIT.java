/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Damini
 */
public class BlackjackIT {

    public BlackjackIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Blackjack.
     */
    @Test
    public void testMain() {

    }

    /**
     * Test of bets method, of class Blackjack.
     */
    @Test
    public void testBets() {
       
    }

    /**
     * Test of payout method, of class Blackjack.
     */
    @Test
    public void testPayout() {

    }

    /**
     * Test of turns method, of class Blackjack.
     */
    @Test
    public void testTurns() {

    }

}
